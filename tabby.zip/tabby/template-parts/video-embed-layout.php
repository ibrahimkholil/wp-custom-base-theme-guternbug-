<div class="hip-video-embed-wrapper">
	<iframe width="1280" height="720" class="hip-video-embed-item" src="<?php echo $videoUrl;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
