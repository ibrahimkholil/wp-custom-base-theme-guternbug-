<?php

/**
 * Initialize theme settings
 */
new \Tabby\ThemeOptions();

/**
 * Initialize custom Gutenberg blocks
 */
add_action('after_setup_theme', function () {
	new \Tabby\GutenbergBlocks();
});

/**
 * tabby functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package tabby
 */

/*
 * Theme Version
 *
 * Added as query strings to stylesheets and scripts to bust  browser cache.
 */

define('THEME_VERSION', '1.5.0');

if (! function_exists('tabby_setup')) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function tabby_setup()
	{
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on tabby, use a find and replace
		 * to change 'tabby' to the name of your theme in all the template files.
		 */
		load_theme_textdomain('tabby', get_template_directory() . '/languages');

		// Add default posts and comments RSS feed links to head.
		add_theme_support('automatic-feed-links');

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support('title-tag');

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support('post-thumbnails');

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus([
			'main'		  =>  esc_html__('Primary menu', 'tabby'),
			'secondary'	  =>  esc_html__('Secondary header menu', 'tabby'),
			'footer'	  => esc_html__('Footer Menu', 'tabby'),
			'mobile'	  => esc_html__('Mobile Dropdown Menu', 'tabby'),
			'hero'		  => esc_html__('Hero Dropdown Menu', 'tabby')
		]);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support('html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		));

		// Set up the WordPress core custom background feature.
		add_theme_support('custom-background', apply_filters('tabby_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		)));

		// Add theme support for selective refresh for widgets.
		add_theme_support('customize-selective-refresh-widgets');

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support('custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		));
		/**
		 * can be moved into separate function or file
		 */
		add_shortcode('tabby-breadcrumbs', function ($atts) {
			global $post;
			if ($post) {
				$breadcrumbs = new \Tabby\Breadcrumbs($post);
				return $breadcrumbs->render();
			}
			return false;
		});

		/**
		 * add image size tabby theme
		 */
		add_image_size('100x65', 100, 65);
		add_image_size('770x385', 770, 385, true);
		add_image_size('737x478', 737, 478, true);
	}
endif;
add_action('after_setup_theme', 'tabby_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function tabby_content_width()
{
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters('tabby_content_width', 640);
}
add_action('after_setup_theme', 'tabby_content_width', 0);

/**
 * Enqueue scripts and styles.
 */
function tabby_scripts()
{
	/**
	 * Styles
	 */
	if (!is_plugin_active('hip-reviews/plugin.php')) {
		wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/dist/lib/owl-carousel/dist/assets/owl.carousel.min.css');
	}
	
	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/dist/lib/bootstrap/css/bootstrap.min.css');
	wp_enqueue_style('tabby-main', get_template_directory_uri() . '/dist/css/combined.css');
	wp_enqueue_style('tabby-font-awesome-5', get_template_directory_uri() . '/dist/vendor/fontawesome/css/all.css');

	/**
	 * Scripts
	 */
	wp_enqueue_script('bootstrap', get_template_directory_uri() . '/dist/lib/bootstrap/js/bootstrap.min.js', ['jquery'], '4.3.1', true);
	wp_enqueue_script('tabby-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true);
	wp_enqueue_script('tabby-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
	if (!is_plugin_active('hip-reviews/plugin.php')) {
		wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/dist/lib/owl-carousel/dist/owl.carousel.min.js', ['jquery'], '', true);
	}
	wp_enqueue_script('tabby-main', get_template_directory_uri() . '/dist/js/combined.js', ['jquery'], THEME_VERSION, true);
}
add_action('wp_enqueue_scripts', 'tabby_scripts');
function tabbyAdminScripts()
{
	wp_enqueue_style('tabby-admin-main', get_template_directory_uri().'/dist/css/admin.css', '', THEME_VERSION);
	wp_enqueue_script('tabby-admin-main', get_template_directory_uri() . '/dist/js/combined-admin.js', ['jquery'], THEME_VERSION, true);
	wp_localize_script('tabby-admin-main', 'ajaxOptions', [
		'ajaxUrl' => admin_url('admin-ajax.php')
	]);
}
add_action('admin_enqueue_scripts', 'tabbyAdminScripts');

/**
 * include theme scripts
 */
function includeFiles()
{
	/**
	 * Implement the Custom Header feature.
	 */
	require get_template_directory() . '/inc/custom-header.php';

	/**
	 * Custom template tags for this theme.
	 */
	require get_template_directory() . '/inc/template-tags.php';

	/**
	 * Functions which enhance the theme by hooking into WordPress.
	 */
	require get_template_directory() . '/inc/template-functions.php';

	/**
	 * Customizer additions.
	 */
	require get_template_directory() . '/inc/customizer.php';
	/**
	 * widget areas
	 */
	include get_template_directory() . '/inc/widgetAreas.php';
	/**
	 * Recent Post widget
	 */
	include get_template_directory() . '/inc/widgets/recent-post.php';
	/**
	 * Recent Post widget
	 */
	include get_template_directory() . '/inc/widgets/popular-categories.php';
}

add_action('after_setup_theme', 'includeFiles');

/**
 * Add support for beaver themer header and footer.
 */
function tabby_bb_header_footer_support()
{
	add_theme_support('fl-theme-builder-headers');
	add_theme_support('fl-theme-builder-footers');
	add_theme_support('fl-theme-builder-parts');
}
add_action('after_setup_theme', 'tabby_bb_header_footer_support');

add_action('wp_head', function () {
	$files = glob(get_template_directory().'/inc/css/*.css.php');
	ob_start();
	?>
	<style id="tabby-dynamic-css" type="text/css">
		<?php
		foreach ($files as $file) {
			include($file);
		}
		?>
	</style>
	<?php
	return ob_get_flush();
});
// Apply filter
add_filter('body_class', function ($classes) {
	global $tabbyFields;
	$isSticky = $tabbyFields['tabby_sticky_header'];
	$headerLayout = $tabbyFields['tabby_header_layout'];
	$mobileMenu = $tabbyFields['tabby_menu_layout'];
	$mobileMenuClass = 'tabby-hamburger-menu';
	if ($isSticky == 'yes') {
		$classes[] = 'tabby-sticky-header';
	}
	if ($mobileMenu == 'tabbar_top') {
		$mobileMenuClass = 'tabby-tabbar-top';
	}
	if ($mobileMenu == 'tabbar_bottom') {
		$mobileMenuClass = 'tabby-tabbar-bottom';
	}
	$classes[] = 'tabby-header-'.$headerLayout;
	$classes[] = $mobileMenuClass;
	return $classes;
});
add_action('admin_head', function () {
	ob_start();
	?>
	<style id="tabby-admin-css" type="text/css">
		body .wp-block{
			max-width: 100%;
		}
		body .block-editor-block-list__layout .block-editor-default-block-appender > .block-editor-default-block-appender__content:empty{
			margin-top:5px;
			margin-bottom: 5px;
		}
		body .ugb-container{
			padding: 35px;
		}
	</style>
	<?php
	return ob_get_flush();
});

add_action('wp_ajax_get_post_type_terms', 'get_post_type_terms');
function get_post_type_terms()
{
	$postType =  $_POST['postType'];
	$taxonomies = get_taxonomies(array(
		'object_type' => [$postType],
	), 'ids', 'and');
	$taxonomy = reset($taxonomies);
	if ($taxonomy != null) {
		$terms   = get_terms(array(
			'taxonomy'   => $taxonomy->name,
			'hide_empty' => false,
		));
		if (!empty($terms)) {
			$allTerms = [];
			foreach ($terms as $term) {
				$allTerms[] = [
					'id' => $term->term_id,
					'name' => $term->name
				];
			}
			if (isset($_POST['withSelected'])) {
				$selected = get_option('hip_post_block_category');
				echo json_encode([
					'status' => 'has_terms',
					'taxonomy_slug'=>$taxonomy->name,
					'taxonomy_label'=>$taxonomy->label,
					'terms' => $allTerms,
					'selected'=> $selected
				]);
			} else {
				echo json_encode([
					'status' => 'has_terms',
					'taxonomy_slug'=>$taxonomy->name,
					'taxonomy_label'=>$taxonomy->label,
					'terms' => $allTerms,
				]);
			}
		}
	} else {
		echo json_encode([
			'status' => 'no_terms',
			'terms' => [],
		]);
	}
	wp_die();
}
add_action('wp_ajax_save_post_block_category', 'save_post_block_category');
function save_post_block_category()
{
	$categoryId =  $_POST['categoryId'];
	$updated = update_option('hip_post_block_category', $categoryId);
	if ($updated) {
		echo json_encode([
			'status' => 'updated successfully',
		]);
	}
	wp_die();
}

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**all custom fields global values**/
add_action('init', 'globalCustomFields');
function globalCustomFields()
{
	global $tabbyFields;
	$tabbyFields = array(
		'tabby_img_logo'=> carbon_get_theme_option('tabby_img_logo'),
		'tabby_alt_img_logo'=> carbon_get_theme_option('tabby_alt_img_logo'),
		'tabby_sticky_header'=> carbon_get_theme_option('tabby_sticky_header'),
		'tabby_header_layout'=> carbon_get_theme_option('tabby_header_layout'),
		'tabby_menu_layout'=> carbon_get_theme_option('tabby_menu_layout'),
		'tabby_header_height_top'=> carbon_get_theme_option('tabby_header_height_top'),
		'tabby_header_height_main'=> carbon_get_theme_option('tabby_header_height_main'),
		'tabby_archive_banner_image'=> carbon_get_theme_option('tabby_archive_banner_image'),
		'tabby_hamburger_menu_width'=> carbon_get_theme_option('tabby_hamburger_menu_width'),
		'tabby_hide_windows_larger_than'=> carbon_get_theme_option('tabby_hide_windows_larger_than'),
		'tabby_hamburger_wrapper_bg'=> carbon_get_theme_option('tabby_hamburger_wrapper_bg'),
		'tabby_header_cta_btn_style'=> carbon_get_theme_option('tabby_header_cta_btn_style'),
		'tabby_business_address'=> carbon_get_theme_option('tabby_business_address'),
		'tabby_business_phone_number'=> carbon_get_theme_option('tabby_business_phone_number'),
		'tabby_social_meida'=> carbon_get_theme_option('tabby_social_meida'),
		'tabby_staff_archive_layout'=> carbon_get_theme_option('tabby_staff_archive_layout'),
		'tabby_header_cta_btn_bg_text_hover_color'=> carbon_get_theme_option('tabby_header_cta_btn_bg_text_hover_color'),
		'tabby_header_cta_btn_bg_hover_color'=> carbon_get_theme_option('tabby_header_cta_btn_bg_hover_color'),
		'tabby_header_cta_btn_border_outside'=> carbon_get_theme_option('tabby_header_cta_btn_border_outside'),
		'tabby_above_footer_section_height'=> carbon_get_theme_option('tabby_above_footer_section_height'),
		'tabby_above_footer_submit_success_message_color'=> carbon_get_theme_option('tabby_above_footer_submit_success_message_color'),
		'tabby_background_color'=> carbon_get_theme_option('tabby_background_color'),
		'tabby_hover_background_color'=> carbon_get_theme_option('tabby_hover_background_color'),
		'tabby_text_link_color'=> carbon_get_theme_option('tabby_text_link_color'),
		'tabby_search_button_text_color'=> carbon_get_theme_option('tabby_search_button_text_color'),
		'tabby_search_enable'=> carbon_get_theme_option('tabby_search_enable'),
		'tabby_primary_color'=> carbon_get_theme_option('tabby_primary_color'),
		'tabby_link_color'=> carbon_get_theme_option('tabby_link_color'),
		'tabby_link_hover_color'=> carbon_get_theme_option('tabby_link_hover_color'),
		'tabby_header_main_desktop_icon_color'=> carbon_get_theme_option('tabby_header_main_desktop_icon_color'),
		'tabby_header_top_bg'=> carbon_get_theme_option('tabby_header_top_bg'),
		'tabby_header_top_link_color'=> carbon_get_theme_option('tabby_header_top_link_color'),
		'tabby_header_top_link_hover'=> carbon_get_theme_option('tabby_header_top_link_hover'),
		'tabby_header_menu_color'=> carbon_get_theme_option('tabby_header_menu_color'),
		'tabby_header_menu_color_hover'=> carbon_get_theme_option('tabby_header_menu_color_hover'),
	);
}
